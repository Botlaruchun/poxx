import os

from bot.core.agents import generate_random_user_agent
from bot.utils import logger
from bot.config import settings
from bot.utils.file_manager import load_from_json, save_to_json


class Accounts:
    def __init__(self):
        self.workdir = "sessions/"
        self.api_id = settings.API_ID
        self.api_hash = settings.API_HASH

    @staticmethod
    def get_available_accounts(sessions: list):

        accounts_from_json = load_from_json('sessions/accounts.json')

        if not accounts_from_json:
            raise ValueError("Доступные аккаунты не найдены!")

        available_accounts = []
        for session in sessions:
            is_session_added = False
            for saved_account in accounts_from_json:
                if saved_account['session_name'] == session:
                    available_accounts.append(saved_account)
                    is_session_added = True
                    break
            if not is_session_added:
                logger.warning(f'{session}.session не найдена')
                ans = input(f"Добавить {session} (y/N): ")
                if 'y' in ans.lower():
                    raw_proxy = input("Введи прокси в формате type://user:pass:ip:port (нажми Enter чтобы продолжить без прокси): ")
                    user_agent = generate_random_user_agent(device_type='android', browser_type='chrome')
                    new_account = {
                         "session_name": session,
                         "user_agent": user_agent,
                         "proxy": raw_proxy
                    }
                    save_to_json(f'sessions/accounts.json', dict_=new_account)
                    available_accounts.append(new_account)
                    logger.success(f'Аккаунт {session} добавлен в список')

        return available_accounts

    def pars_sessions(self):
        sessions = []
        for file in os.listdir(self.workdir):
            if file.endswith(".session"):
                sessions.append(file.replace(".session", ""))

        logger.info(f"Searched sessions: {len(sessions)}.")
        return sessions

    async def get_accounts(self):
        sessions = self.pars_sessions()
        available_accounts = self.get_available_accounts(sessions)

        if not available_accounts:
            raise ValueError("Доступные аккаунты не найдены!")
        else:
            logger.success(f"Доступные аккаунты: {len(available_accounts)}.")

        return available_accounts
