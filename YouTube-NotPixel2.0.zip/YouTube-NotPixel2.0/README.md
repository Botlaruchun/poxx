# 🔥 АвтоФарм NotPixel 🔥

## YouTube - https://www.youtube.com/@rmsudo
## NotPixel bot - https://t.me/notpixel/app?startapp=f5064842218

## Features  
| Возможности                                               |Поддерживает|
|-----------------------------------------------------------|:----------:|
| Много аккаунтов                                           |     ✅     |
| Proxy                                                     |     ✅     |
| Разные юзер агенты                                        |     ✅     |
| Поддержка pyrogram .session                               |     ✅     |
| Автоматическая регистрация в боте                         |     ✅     |
| Автоматические задания                                    |     ✅     |
| Дневные награды                                           |     ✅     |


# Linux
```shell
pip3 install -r requirements.txt
# нужно зайти в файл bot/config/config.py и там указать API_ID и API_HASH
nano bot/config/config.py
python3 main.py
```

# Windows
```shell
pip install -r requirements.txt
# нужно зайти в файл bot/config/config.py и там указать API_ID и API_HASH
python main.py
```
PS: вы сами решаете использовать этого бота или нет, разработчик ответственности не несет!